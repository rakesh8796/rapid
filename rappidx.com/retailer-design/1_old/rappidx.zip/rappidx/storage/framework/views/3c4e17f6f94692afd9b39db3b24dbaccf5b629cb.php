
<?php $__env->startSection("retailer"); ?>
<div class="main-content">
    <section class="section">
        <div class="row">
            <div class="col-12 col-sm-12 col-lg-12">
                <div class="card ">
                    <div class="card-header">
                        <h4>Calculate Estimate Amount</h4>

                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 ">
                                <div class="row">
                                    <div class="col-md-12 ">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Pickup Pincode</label>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <div class="input-group-text">
                                                                <i data-feather="map-pin"></i>
                                                            </div>
                                                        </div>
                                                        <input type="text" class="form-control phone-number">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Delivery Pincode</label>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <div class="input-group-text">
                                                                <i data-feather="map-pin"></i>
                                                            </div>
                                                        </div>
                                                        <input type="text" class="form-control phone-number">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Weight</label>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <div class="input-group-text">
                                                                <i>KG</i>
                                                            </div>
                                                        </div>
                                                        <input type="text" class="form-control phone-number">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>L(cm)</label>
                                            <div class="input-group">

                                                <input type="text" class="form-control phone-number">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>H(cm)</label>
                                            <div class="input-group">

                                                <input type="text" class="form-control phone-number">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>B(cm)</label>
                                            <div class="input-group">

                                                <input type="text" class="form-control phone-number">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                    <div class="form-group">
                                            <label>Value in INR</label>
                                            <div class="input-group">

                                                <input type="text" class="form-control phone-number">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3"> 
                                        <div class="form-group">
                                            <label>COD</label>
                                            <div class="input-group">

                                            <select class="form-control">
                                                                        
                                                                        <option>YES</option>
                                                                        <option>NO</option>
                                            </select>
                                            </div>
                                        </div></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4"><div class="form-group">
                                                    <label>select Category</label>
                                                    <div class="input-group">
                                                       
                                                    <select class="form-control">
                                                                        <option>Product Category*</option>
                                                                        <option>Apparel And Accessories</option>
                                                                        <option>Automotives</option>
                                                                        <option>Baby Care</option>
                                                                        <option>Books And Stationery</option>
                                                                        <option>Consumables FMCG</option>
                                                                        <option>Documents</option>
                                                                        <option>Electronics</option>
                                                                        <option>Household Items</option>
                                                                        <option>Sports Equipments</option>
                                                                        <option>Covid Essentials</option>
                                                                        <option>Other</option>
                                                                    </select>
                                                    </div>
                                                </div></div>
                                    <div class="col-md-4"><div class="form-group">
                                                    <label>Product Amount</label>
                                                    <div class="input-group">
                                                        
                                                        <input type="text" class="form-control phone-number">
                                                    </div>
                                                </div></div>
                                </div>
                                <div class="my-3 col-md-4  ">
                                    <a href="#" class="btn btn-primary form-control">&nbsp;Calculate</i></a>

                                </div>


                            </div>
                            <div class="col-md-6">
                            
                            <div class="card-header">
                            <h4>Terms & Conditions:</h4>

                    </div>
                            <ul>
                                <li>Above Shared Commercials are Exclusive GST.</li>
                                <li>Above pricing subject to change based on courier company updation or change in any commercials.</li>
                                <li>Freight Weight is Picked - Volumetric or Dead weight whichever is higher will be charged.</li>
                                <li>Return charges as same as Forward for currier's where special RTO pricing is not shared.</li>
                                <li>Return charges as same as Forward for currier's where special RTO pricing is not shared.</li>
                                <li>Other charges like address correction charges if applicable shall be charged extra.</li>
                                <li>Prohibited item not to be ship, if any penalty will charge to seller.</li>
                            </ul>
                            </div>








                        </div>

                    </div>
                </div>
            </div>
        </div>
</div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("retailer/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\office\rappidx\resources\views/retailer/Calculater.blade.php ENDPATH**/ ?>