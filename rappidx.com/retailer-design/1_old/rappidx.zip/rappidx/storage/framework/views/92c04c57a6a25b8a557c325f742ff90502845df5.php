<?php echo $__env->make("retailer/layouts/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
  
  
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <?php echo $__env->make("retailer/layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make("retailer/layouts/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Main Content -->
      <?php $__env->startSection("retailer"); ?>

      <?php echo $__env->yieldSection(); ?>
      
      <?php echo $__env->make("retailer/layouts/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\Philon_Technology\#_Personal_Work\Sashi_Transfer-File\3\rappidx\resources\views/retailer/app.blade.php ENDPATH**/ ?>