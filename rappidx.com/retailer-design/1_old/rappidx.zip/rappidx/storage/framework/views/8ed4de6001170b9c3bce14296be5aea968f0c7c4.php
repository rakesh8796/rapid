<footer class="main-footer">
        <div class="footer-left">
          <a href="templateshub.net">Templateshub</a></a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  

  <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/bundles/apexcharts/apexcharts.min.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/page/index.js')); ?>"></script>
 
  <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
</body>




  
</body>


<!-- datatables.html  21 Nov 2019 03:55:25 GMT -->
</html><?php /**PATH E:\Xampp\htdocs\Philon_Technology\#_Personal_Work\Sashi_Transfer-File\3\rappidx\resources\views/retailer/layouts/footer.blade.php ENDPATH**/ ?>