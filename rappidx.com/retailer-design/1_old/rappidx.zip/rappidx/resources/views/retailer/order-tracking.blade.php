@extends("retailer/app")
@section("retailer")

<div class="main-content">
    <section class="section">
        <div class="row">
            <div class="col-12 col-sm-12 col-lg-12">
                <div class="card ">
                    <div class="card-header">
                        <h4>Order Tracking/Real Time</h4>

                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="row">
                                <div class="list-inline col-md-6 ">

                                    <textarea class="form-control"  placeholder="Search Order Details Write AWB Number"></textarea>
                                </div>
                                <div class="my-3 col-md-2  "> 
                                <a href="#" class="btn btn-primary form-control">&nbsp;Track Order Now</i></a>
                                        
                                </div>
                                </div>
                                

                            </div>








                        </div>

                    </div>
                </div>
            </div>
        </div>
</div>
</section>
</div>

@endsection()