
<aside id="sidebar-wrapper">
<div class="sidebar-brand" style="background-color:yellow ;">
<a href="index.html"> <img alt="image" src="assets/img/reppidxlogoicon.png" class="header-logo" /> <span class="logo-name"><img alt="image" src="assets/img/logo.png" class="header-logo" /></span>
</a>
</div>
<ul class="sidebar-menu">
<li class="menu-header">Main</li>
<li class="dropdown active">
<a href="dashboard.php" class="nav-link"><i data-feather="monitor"></i><span>Franchise</span></a>
</li>
<li class="dropdown">
<a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="briefcase"></i><span>Orders Off</span></a>
<ul class="dropdown-menu">
  <li><a class="nav-link" href="order.php">Orders</a></li>
</ul>
</li>
<li class="dropdown">
<a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Upload Orders</span></a>
<ul class="dropdown-menu">
  <li><a class="nav-link" href="bulk-order.php">Bulk Order</a></li>
  <li><a class="nav-link" href="book-single-order.php">Book Single Orders</a></li>
  <!-- <li><a class="nav-link" href="single-order.php" data-toggle="modal" data-target="#exampleModalCenter">Book Single Orders</a></li> -->
  <li><a class="nav-link" href="single-order.php">Today Single Order</a></li>
</ul>
</li>
<li class="dropdown">
<a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Reports</span></a>
<ul class="dropdown-menu">
  <li><a class="nav-link" href="mis.php">MIS</a></li>

</ul>
</li>
<li><a class="nav-link" href="calculator.php"><i data-feather="layout"></i><span>Calculator off</span></a></li>
<li><a class="nav-link" href="wallet.php"><i class="fa fa-wallet "></i><span>Wallet</span></a></li>
<li><a class="nav-link" href="pincode.php"><i data-feather="map-pin"></i><span>Pincode</span></a></li>
<li><a class="nav-link" href="print-shipping-labels.php"><i data-feather="copy"></i><span>Print Shipping Labels</span></a></li>
<li><a class="nav-link" href="order-tracking.php"><i data-feather="map"></i><span>Order Tracking</span></a></li>

</ul>
</aside>
