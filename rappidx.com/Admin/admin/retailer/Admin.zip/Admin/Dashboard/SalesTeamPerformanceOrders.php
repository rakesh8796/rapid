<style type="text/css">
th,td{
    padding:5px !important;
    font-size: 12px;
}
</style>

<div class="row">
<div class="col-sm-6">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Month Wise Booking Count Orders</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
 <table class="table">
    <thead>
      <tr>
        <th title="">BD_Name</th>
        <th title="">Jan_21</th>
        <th title="">Feb_21</th>
        <th title="">Mar_21</th>
        <th title="">Apr_21</th>
        <!-- <th style="padding: 5px !important" title="">May_21</th> -->
        <!-- <th style="padding: 5px !important" title="">Jun_21</th>
        <th style="padding: 5px !important" title="">Jul_21</th>
        <th style="padding: 5px !important" title="">Aug_21</th>
        <th style="padding: 5px !important" title="">Sep_21</th>
        <th style="padding: 5px !important" title="">Oct_21</th>
        <th style="padding: 5px !important" title="">Nov_21</th>
        <th style="padding: 5px !important" title="">Dec_21</th> -->
      </tr>
    </thead>
    <tbody>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="ASales&Performance_Month.php">Order Count View All</a></b></u></h5>-->
</div>
</div>
<div class="col-sm-6">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Current Month Booking Client Wise</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
 <table class="table">
    <thead>
      <tr>
        <th title="">BD_Name1</th>
        <th title="">Jan_211</th>
        <th title="">Feb_21</th>
        <th title="">Mar_21</th>
        <th title="">Apr_21</th>
        <!-- <th style="padding: 5px !important" title="">May_21</th> -->
        <!-- <th style="padding: 5px !important" title="">Jun_21</th>
        <th style="padding: 5px !important" title="">Jul_21</th>
        <th style="padding: 5px !important" title="">Aug_21</th>
        <th style="padding: 5px !important" title="">Sep_21</th>
        <th style="padding: 5px !important" title="">Oct_21</th>
        <th style="padding: 5px !important" title="">Nov_21</th>
        <th style="padding: 5px !important" title="">Dec_21</th> -->
      </tr>
    </thead>
    <tbody>
        <tr>
            <td>Client 11</td>
            <td>10</td>
            <td>100</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Client 1</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="ASales&Performance_Client.php">Clients Wise View All</a></b></u></h5>-->
</div>
</div>

</div>
<!-- /.row -->
