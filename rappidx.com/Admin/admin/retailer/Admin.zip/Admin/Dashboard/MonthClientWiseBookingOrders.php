<style type="text/css">
th,td{
    padding:5px !important;
    font-size: 12px;
}
</style>
<div class="row">
<div class="col-sm-4">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Month  Wise Booking Orders</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
  <table class="table">
    <thead>
      <tr>
        <th>Month</th>
        <th>COD</th>
        <th>Prepaid</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
        <tr>
            <td>August</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>July</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>June</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>May</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>April</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="AMonth_Wise.php">View All</a></b></u></h5>-->
</div>
</div>
<div class="col-sm-4">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Current Month Booking</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
  <table class="table">
    <thead>
      <tr>
        <th>Date</th>
        <th>COD</th>
        <th>Prepaid</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
        <tr>
            <td>11/08/21</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>10/08/21</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>09/08/21</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>08/08/21</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>07/08/21</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="ACurrent_Month.php">View All</a></b></u></h5>-->
</div>
</div>
<div class="col-sm-4">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Current Month Booking Client Wise</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
  <table class="table">
    <thead>
      <tr>
        <th>C_Name</th>
        <th>COD</th>
        <th>Prepaid</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
        <tr>
            <td>Enterpr..</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Enterpri</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Enterpri</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Enterpri</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>Enterpri</td>
            <td>00</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="ACurrent_Month_Client.php">View All</a></b></u></h5>-->
</div>
</div>
</div>
<!-- /.row -->
