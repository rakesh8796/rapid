<style type="text/css">
th,td{
    padding:5px !important;
    font-size: 12px;
}
</style>

<div class="row">
<div class="col-sm-6">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Month Wise Booking Orders</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
 <table class="table ">
    <thead>
      <tr>
        <th title="Month Wise">Month</th>
        <th title="Booking Count">Book</th>
        <th title="Connection Count">Conn</th>
      </tr>
    </thead>
    <tbody>
        <tr>
            <td>August</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>July</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>June</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>May</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>April</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="ABooking&Connection_CMonth.php">Current Month View All</a></b></u></h5>-->
</div>
</div>
<div class="col-sm-6">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Current Month Booking</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
  <table class="table">
    <thead>
      <tr>
        <th title="Current Dates">Date 1</th>
        <th title="Booking Count">Book1</th>
        <th title="Connection Count">Conn 1</th>
      </tr>
    </thead>
    <tbody>
         <tr>
            <td>11/08/211</td>
            <td>010</td>
            <td>010</td>
        </tr>
        <tr>
            <td>101/08/21</td>
            <td>001</td>
            <td>010</td>
        </tr>
        <tr>
            <td>09/08/21</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>08/08/21</td>
            <td>00</td>
            <td>00</td>
        </tr>
        <tr>
            <td>07/08/21</td>
            <td>00</td>
            <td>00</td>
        </tr>
    </tbody>
  </table>
</div>
<!--<h5 class="text-center"><u><b><a href="ABooking&Connection_Month.php">Month Wise View All</a></b></u></h5>-->
</div>
</div>
</div>
<!-- /.row -->
