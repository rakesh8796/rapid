<?php

$conn=mysqli_connect("localhost","root","","philonwfh_rappidx");
// $conn=mysqli_connect("localhost","rappidx","UCjZV0l[TJGY","rappidx");
// $conn=mysqli_connect("localhost","badmagwl_rappidx","uJ&4_t)kD@&d","badmagwl_rappidx");

date_default_timezone_set('Asia/Kolkata');

?>
