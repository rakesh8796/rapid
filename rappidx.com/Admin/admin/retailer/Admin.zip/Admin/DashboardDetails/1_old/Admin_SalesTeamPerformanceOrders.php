<style type="text/css">
th,td{
    padding:5px !important;
    font-size: 12px;
}
</style>

<div class="row">
<div class="col-sm-6">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Month Wise Booking Count Orders</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
  <center><br><br>
    Soon
  <br><br><br></center>
</div>
<!--<h5 class="text-center"><u><b><a href="ASales&Performance_Month.php">Order Count View All</a></b></u></h5>-->
</div>
</div>
<div class="col-sm-6">
<div class="white-box">
<span style="color:black;font-weight:400"><center>Current Month Booking Client Wise</center></span>
<div class="table-responsive color-bordered-table muted-bordered-table fontweigh">
  <center><br><br>
    Soon
  <br><br><br></center>
</div>
<!--<h5 class="text-center"><u><b><a href="ASales&Performance_Client.php">Clients Wise View All</a></b></u></h5>-->
</div>
</div>

</div>
<!-- /.row -->
